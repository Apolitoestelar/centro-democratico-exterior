
  # Landing Page for Political Campaign

  This is a code bundle for Landing Page for Political Campaign. The original project is available at https://www.figma.com/design/i1iNYq4Wy5hCX4HzwxBOMJ/Landing-Page-for-Political-Campaign.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  